@echo off
title Xbox 360 NetISO Server

REM ==================================================
REM EDIT THIS PATH TO THE FOLDER YOU WANT TO SHARE
REM ==================================================
set "SHARE_FOLDER=D:\Program Files\Blahpr Software Inc\360 Utility Batch Create Extract v1.2 Language Support\x_ISO"

REM Start server.exe as if the folder was dragged onto it
"%~dp0server.exe" "%SHARE_FOLDER%"

pause