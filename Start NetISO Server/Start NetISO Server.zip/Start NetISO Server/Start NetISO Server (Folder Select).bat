@echo off
title Xbox 360 NetISO Server
setlocal EnableDelayedExpansion

set "LASTFILE=%~dp0last_folder.txt"
set "SHARE_FOLDER="
set "BAT_PATH=%~f0"
set "BAT_DIR=%~dp0"

REM ============================================================
REM Load last folder if it exists
REM ============================================================
if exist "%LASTFILE%" (
set /p "SHARE_FOLDER="<"%LASTFILE%"
)

REM ============================================================
REM If saved folder doesn't exist, forget it
REM ============================================================
if defined SHARE_FOLDER (
if not exist "!SHARE_FOLDER!" (
del "%LASTFILE%" >nul 2>&1
set "SHARE_FOLDER="
)
)

REM ============================================================
REM AUTO-START SAVED FOLDER
REM If a valid saved folder exists, skip folder selection
REM ============================================================
if defined SHARE_FOLDER goto START_SERVER

REM ============================================================
REM Ask for folder only if none is saved
REM ============================================================
if not defined SHARE_FOLDER (
echo Opening folder selector...
echo.

for /f "delims=" %%I in ('powershell.exe -NoProfile -Command "Add-Type -AssemblyName System.Windows.Forms; $f=New-Object System.Windows.Forms.FolderBrowserDialog; $f.Description='Select the folder to share with NetISO'; $f.ShowNewFolderButton=$false; if($f.ShowDialog() -eq 'OK'){Write-Output $f.SelectedPath}"') do (
    set "SHARE_FOLDER=%%I"
)

if not defined SHARE_FOLDER (
    echo.
    echo No folder was selected.
    echo.
    pause
    exit /b
)

REM Save the selected folder
>"%LASTFILE%" echo(!SHARE_FOLDER!

)

REM ============================================================
REM Start Server
REM ============================================================
:START_SERVER

REM ============================================================
REM Get the actual Windows Desktop location
REM ============================================================
set "DESKTOP_PATH="

for /f "usebackq delims=" %%D in (`powershell.exe -NoProfile -Command "[Environment]::GetFolderPath('Desktop')"`) do (
set "DESKTOP_PATH=%%D"
)

REM ============================================================
REM Desktop shortcut option
REM Ask only if shortcut does not already exist
REM ============================================================
if defined DESKTOP_PATH (
set "DESKTOP_SHORTCUT=!DESKTOP_PATH!\Xbox 360 NetISO Server.lnk"

if not exist "!DESKTOP_SHORTCUT!" (
    cls
    echo ==========================================
    echo   Desktop Shortcut
    echo ==========================================
    echo.
    choice /C YN /N /M "Would you like to create a Desktop shortcut? (Y/N): "

    if !errorlevel! equ 1 (
        powershell.exe -NoProfile -Command "$ws=New-Object -ComObject WScript.Shell; $s=$ws.CreateShortcut('!DESKTOP_SHORTCUT!'); $s.TargetPath='!BAT_PATH!'; $s.WorkingDirectory='!BAT_DIR!'; $s.Description='Xbox 360 NetISO Server'; $s.Save()"
    )
)

)

REM ============================================================
REM Clean everything above the NetISO header
REM ============================================================
cls

echo ==========================================
echo   Xbox 360 NetISO Server
echo ==========================================
echo.
echo Sharing:
echo "!SHARE_FOLDER!"
echo.

REM ============================================================
REM Make sure server.exe exists
REM ============================================================
if not exist "%~dp0server.exe" (
echo ERROR: server.exe was not found!
echo.
echo Expected location:
echo "%~dp0server.exe"
echo.
pause
exit /b
)

echo Starting server.exe...
echo.

REM ============================================================
REM Start NetISO
REM ============================================================
"%~dp0server.exe" "!SHARE_FOLDER!"

echo.
echo server.exe has closed.
echo.
pause
